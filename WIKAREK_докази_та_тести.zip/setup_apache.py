from pathlib import Path
import subprocess
p=Path('/data/audit/work/labs/Lab_01/Pliki_do_skopiowania');pma=Path('/data/audit/phpmyadmin-placeholder');pma.mkdir(exist_ok=True);(pma/'index.html').write_text('phpMyAdmin location placeholder, not real installation')
subprocess.run(['openssl','req','-x509','-newkey','rsa:2048','-nodes','-keyout',str(p/'ssl/meble.key'),'-out',str(p/'ssl/meble.crt'),'-days','1','-subj','/C=PL/ST=3ID11B/L=97882-97889/CN=www.meble.pl'],capture_output=True,check=True)
frag=Path('/data/wikarek/04-Gotowe_Laborki/Lab_01/httpd_append.conf').read_text().replace('D:/Studenci/Cw_01/3ID11B_01',str(p)).replace('C:/Oprogramowanie/Apache24/htdocs/phpMyAdmin',str(pma)).replace('10.0.2.2','127.0.0.2').replace('10.0.3.3','127.0.0.3').replace(':8080>',':18081>').replace(':443>',':18443>').replace(':80>',':18080>').replace('Listen 8080','Listen 18081').replace('Listen 443 https','Listen 18443 https')
mods=['mpm_event','unixd','authn_core','authz_core','authn_file','authz_user','authz_host','auth_basic','dir','mime','autoindex','alias','status','socache_shmcb','ssl','log_config']
conf='ServerRoot "/etc/httpd"\nServerName localhost\nDefaultRuntimeDir "/data/audit"\nPidFile "/data/audit/apache.pid"\nErrorLog "/data/audit/apache-errors.log"\nListen 18080\nTypesConfig /etc/mime.types\nUser vercel-sandbox\nGroup vercel-sandbox\n'
conf+=''.join(f'LoadModule {m}_module /usr/lib64/httpd/modules/mod_{m}.so\n' for m in mods)
conf+='<Directory />\n Require all denied\n</Directory>\n'+frag
Path('/data/audit/apache.conf').write_text(conf)
