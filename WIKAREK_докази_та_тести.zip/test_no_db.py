from pathlib import Path
from lxml import etree,html
import urllib.request,urllib.parse,http.cookiejar,json,subprocess,zipfile,hashlib,base64
root=Path('/data/wikarek'); out={}; base='http://127.0.0.1:8765/'
def client(): return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
def req(c,p,data=None):
 r=c.open(base+p, None if data is None else urllib.parse.urlencode(data,doseq=True).encode()); return r.status,r.read().decode(),r.url
xml=[]
for d in sorted((root/'04-Gotowe_Laborki/Lab_06').glob('Wariant*')):
 doc=etree.parse(str(d/'baza.xml'),etree.XMLParser(load_dtd=True,no_network=True)); entry={'variant':d.name,'dtd_valid':doc.docinfo.internalDTD.validate(doc)}
 e1,e2,rel=doc.getroot(); entry['records']=[len(e1),len(e2),len(rel)]
 entry['references_correct_type']=all(r.get('ref1') in [x.get('id') for x in e1] and r.get('ref2') in [x.get('id') for x in e2] for r in rel)
 for name in ['tabela','relacja']:
  result=etree.XSLT(etree.parse(str(d/(name+'.xsl'))))(doc); tree=html.fromstring(str(result)); rows=tree.xpath('//tbody/tr'); entry[name+'_xslt_rows']=len(rows)
  if name=='relacja':entry['join_names_nonempty']=all(''.join(t.itertext()).strip() for row in rows for t in row.xpath('./td')[1:3])
  Path('/data/audit/'+d.name+'_'+name+'.html').write_text(str(result))
 c=client(); path='Lab_06/'+d.name+'/index.php'
 entry['php_all_rows']=len(html.fromstring(req(c,path)[1]).xpath('//tbody/tr'))
 entry['php_filters']=[]
 for e in e1:
  count=len([r for r in rel if r.get('ref1')==e.get('id')]); text=req(c,path,{'ref1_id':e.get('id')})[1]; got=len(html.fromstring(text).xpath('//tbody/tr[td[1]/strong]'))
  entry['php_filters'].append({'id':e.get('id'),'expected':count,'actual':got})
 xml.append(entry)
out['xml']=xml
c=client(); p='Lab_04/a1.php'; valid={'btn_submit':'1','nazwisko':'Kowalski','typ_zajec':'zdalnie','jezyk':'Angielski','data_urodzenia':'2004-05-14','pesel':'04251412345','kursy[]':['Muzyka','Programowanie']}
tests=[]
for name,patch,needle in [('valid',{},'action_confirm'),('empty',{'nazwisko':'','data_urodzenia':'','pesel':'','kursy[]':[]},'Pole nie może być puste'),('impossible_date',{'data_urodzenia':'2000-02-31','pesel':'00023112345'},'Niepoprawna data kalendarzowa'),('pesel_mismatch',{'pesel':'04251512345'},'Niezgodnosc dat'),('under16',{'data_urodzenia':'2020-01-01','pesel':'20210112345'},'16 lat'),('long_surname',{'nazwisko':'A'*25},'24 znak'),('bad_enum',{'typ_zajec':'invalid'},'Wybierz opcje'),('no_course',{'kursy[]':[]},'choć jeden')]:
 data=valid|patch; status,text,url=req(c,p,data); tests.append({'name':name,'status':status,'expected_found':needle in text,'confirmation_shown':'name="action_confirm"' in text})
req(c,p,valid); result=req(c,p,{'action_confirm':'Zapisz'}); tests.append({'name':'save','url':result[2],'file':Path('/data/audit/work/labs/Lab_04/z_001.txt').read_text()})
c2=client(); result=req(c2,p,{'action_confirm':'Zapisz','conf_nazwisko':'INVALID'});tests.append({'name':'direct_save_bypass','redirects_to_form':result[2].endswith('a1.php'),'number_files':len(list(Path('/data/audit/work/labs/Lab_04').glob('z_*.txt')))})
req(c,p,valid); result=req(c,p,{'action_confirm':'Anuluj'});tests.append({'name':'cancel','url':result[2]})
out['lab4']=tests
password=(root/'04-Gotowe_Laborki/Lab_01/Pliki_do_skopiowania/hasla.has').read_text().strip();out['lab1_password_valid']=password=='st:{SHA}'+base64.b64encode(hashlib.sha1(b'st').digest()).decode()
pdf=root/'04-Gotowe_Laborki/Lab_01/Pliki_do_skopiowania/meble80/dokument.pdf';r=subprocess.run(['pdfinfo',str(pdf)],capture_output=True,text=True);out['lab1_sample_pdf']={'exit':r.returncode,'output':r.stdout+r.stderr}
Path('/data/audit/test_no_db.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps(out,ensure_ascii=False,indent=2))
