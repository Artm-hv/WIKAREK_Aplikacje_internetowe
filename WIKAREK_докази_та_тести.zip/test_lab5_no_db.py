import urllib.request,urllib.parse,http.cookiejar,json
from pathlib import Path
base='http://127.0.0.1:8765/Lab_05/';out=[]
for d in sorted(Path('/data/wikarek/04-Gotowe_Laborki/Lab_05').glob('Temat*')):
 c=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar())); item={'theme':d.name}
 for page in ['install.php','admin.php']:
  r=c.open(base+d.name+'/'+page);text=r.read().decode();item[page]={'status':r.status,'install_form':'name="btn_install"' in text,'login_form':'name="btn_login"' in text}
 data=urllib.parse.urlencode({'btn_install':'1','db_name':'bad-name','tbl_prefix':'T_test_','admin_user':'admin','admin_pass':'example123','session_lifetime':'30'}).encode();r=c.open(base+d.name+'/install.php',data);text=r.read().decode();item['invalid_db_name_rejected']='Niepoprawna nazwa bazy' in text
 if (d/'captcha.php').exists():
  r=c.open(base+d.name+'/captcha.php');body=r.read();item['captcha_png']=body.startswith(b'\x89PNG\r\n\x1a\n')
 out.append(item)
Path('/data/audit/test_lab5_no_db.json').write_text(json.dumps(out,ensure_ascii=False,indent=2));print(json.dumps(out,ensure_ascii=False,indent=2))
