import urllib.request,urllib.error,ssl,base64,json
from pathlib import Path
c=urllib.request.build_opener(urllib.request.ProxyHandler({}),urllib.request.HTTPSHandler(context=ssl._create_unverified_context()))
tests=[]
for name,url,host,auth in [('meble80','http://127.0.0.2:18080/','www.meble.pl',False),('autoindex','http://127.0.0.2:18081/','www.meble.pl',False),('status','http://127.0.0.2:18080/status','www.meble.pl',False),('auta_noauth','http://127.0.0.3:18080/','www.auta.pl',False),('auta_auth','http://127.0.0.3:18080/','www.auta.pl',True),('auta8080_auth','http://127.0.0.3:18081/','www.auta.pl',True),('meble404','http://127.0.0.2:18080/no-such-file','www.meble.pl',False),('auta_global404','http://127.0.0.3:18080/no-such-file','www.auta.pl',True),('ssl','https://127.0.0.2:18443/','www.meble.pl',False),('phpmyadmin','http://127.0.0.1:18080/','www.phpmyad.pl',False),('password_public','http://127.0.0.2:18080/../hasla.has','not-mapped',False)]:
 h={'Host':host}
 if auth:h['Authorization']='Basic '+base64.b64encode(b'st:st').decode()
 try:r=c.open(urllib.request.Request(url,headers=h))
 except urllib.error.HTTPError as e:r=e
 text=r.read().decode(errors='replace');tests.append({'name':name,'status':r.status,'size':len(text),'title':text[text.find('<title>')+7:text.find('</title>')],'has_listing':all(x in text for x in ['test.txt','dokument.pdf','foto.jpg']),'has_team':'Hizhovskyi' in text,'has_footer':'Grupa dziekańska' in text})
Path('/data/audit/test_apache.json').write_text(json.dumps(tests,ensure_ascii=False,indent=2));print(json.dumps(tests,ensure_ascii=False,indent=2));print('Log written',Path('/data/audit/work/labs/Lab_01/Pliki_do_skopiowania/historia/p.log').exists())
