<?php
echo 'Ksiega gosci <BR>';
echo '<a href="/rewrite/" > Powrót  </a> <BR>';
?>