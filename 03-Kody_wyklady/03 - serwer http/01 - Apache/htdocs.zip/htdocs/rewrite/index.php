<?php
 if (isset($_GET['dzial']))
 {
  if (($_GET['dzial']=='artykuly') or ($_GET['dzial']=='repozytorium'))
  {
   $sciezka = $_GET['dzial'];
   if (isset($_GET['id']))
   {
     $plik=$sciezka."/".$_GET['id'];
     readfile($plik);
   }else
   { 
    $lista=array();
    $katalog = opendir($sciezka);
    while ($plik = strtolower(readdir($katalog))) 
    {
     if ($plik<>"." && $plik<>"..") if(!is_dir($sciezka.$plik))
     $lista[]=$plik;
    };
    closedir($katalog);
    sort($lista);
    for ($i=0;$i<count($lista);$i++) 
    {
     echo "<br /><a href=\"index.php?dzial=$sciezka&id=$lista[$i]\">$lista[$i]</a>";
    };
    echo '<BR><a href="index.php" > Powrót  </a> <BR>';
   }
  }
  if ($_GET['dzial']=='ksiegagosci')
  {
    echo 'Ksiega gosci <BR>';
    echo '<a href="index.php" > Powrót  </a>';
  }
 } else
 {
  echo 'PRZEGLADASZ SERWIS <BR>';
  echo '<a href="index.php?dzial=artykuly"    > Lista artykulów </a><BR>';
  echo '<a href="index.php?dzial=repozytorium"> Repozytorium    </a><BR>';
  echo '<a href="index.php?dzial=ksiegagosci" > Księga gości    </a><BR>';
 }
?>