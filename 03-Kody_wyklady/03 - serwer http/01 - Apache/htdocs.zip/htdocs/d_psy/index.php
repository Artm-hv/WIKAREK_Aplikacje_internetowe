<?php
echo "To jest strona w PHP przez zerwer APACHE"
?>
